Group 9 Bomberman

There are 4 implimentations of bomberman
	smart A*
	Deep Learning
	Q-Learning
	State Machine
Of the four only smart A* should be tested.
	To do this the normal testcharacter constructor will work.  As will adding
	final parameter of 1

smart A* resides in the testcharacter.py file.

All of the variantX.py files are set up to run the game once with a random seed of 123.
	This was changed for testing to take the current time, and was run in a loop
	for successive games.
